/*
Q1
Structure of a body. 
struct body_t {
  int color ;      
  int radius ;     
  double mass ;    
  double x, y ;    position
  double vx, vy ;  speed.
  double ax, ay ;  acceleration
} ;

Q2
liste chaînéé

Q3
La force applique en 2 dimensions: fx fy

Q4
see code

Q5
for each body
    initialise its position
    apply the forces
    move the body


Q6
code

Q7
vitesse_new = vitesse_old + acceleration*time
position_new = position_old + vitesse*time

Q8
code

Q9
code(force du champs, et frottement)

Q10
acceleration = force/masse

Q11
code

Q12
In the function simulate_bodies, initialise the body with an acceleration of ay = -9.81











*/