rm intiwish
rm -rf build/
