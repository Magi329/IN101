#ifdef __cplusplus
extern "C"
{
#endif
  
  int Inti_new(ClientData clientData, Tcl_Interp *interp, int argc, char *argv[]);
  void init_retcc();

#ifdef __cplusplus
}
#endif

